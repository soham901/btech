-- Create the STUDENT table
CREATE TABLE STUDENT (
    Rno INT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    City VARCHAR(100) NOT NULL,
    DID INT NOT NULL
);

-- Create the ACADEMIC table
CREATE TABLE ACADEMIC (
    Rno INT PRIMARY KEY,
    SPI DECIMAL(3,1) NOT NULL,
    Bklog INT NOT NULL,
    FOREIGN KEY (Rno) REFERENCES STUDENT(Rno)
);

-- Create the DEPARTMENT table
CREATE TABLE DEPARTMENT (
    DID INT PRIMARY KEY,
    DName VARCHAR(100) NOT NULL
);



-- Insert data into the STUDENT table
INSERT INTO STUDENT (Rno, Name, City, DID) VALUES
(101, 'Raju', 'Rajkot', 10),
(102, 'Amit', 'Ahmedabad', 20),
(103, 'Sanjay', 'Baroda', 40),
(104, 'Neha', 'Rajkot', 20),
(105, 'Meera', 'Ahmedabad', 30),
(106, 'Mahesh', 'Baroda', 10);

-- Insert data into the ACADEMIC table
INSERT INTO ACADEMIC (Rno, SPI, Bklog) VALUES
(101, 8.8, 0),
(102, 9.2, 2),
(103, 7.6, 1),
(104, 8.2, 4),
(105, 7.0, 2),
(106, 8.9, 3);

-- Insert data into the DEPARTMENT table
INSERT INTO DEPARTMENT (DID, DName) VALUES
(10, 'Computer'),
(20, 'Electrical'),
(30, 'Mechanical'),
(40, 'Civil');

-- 1
SELECT * FROM STUDENT
WHERE DID = (SELECT DID FROM DEPARTMENT WHERE DName = 'Computer');

-- 2
SELECT Name FROM STUDENT
WHERE Rno IN (SELECT Rno FROM ACADEMIC WHERE SPI > 8);


-- 3
SELECT * FROM STUDENT
WHERE CITY = 'Rajkot' AND DID = (SELECT DID FROM DEPARTMENT WHERE DName = 'Computer');


-- 4
SELECT COUNT(Rno) FROM STUDENT
WHERE DID = (SELECT DID FROM DEPARTMENT WHERE DName = 'Electrical');


-- 5
SELECT Name FROM STUDENT
WHERE Rno = (SELECT Rno FROM ACADEMIC WHERE SPI = (SELECT MAX(SPI) FROM ACADEMIC));


-- 6
SELECT Name FROM STUDENT
WHERE Rno IN (SELECT Rno FROM ACADEMIC WHERE Bklog > 1);


-- 7
select Name from STUDENT
where rno = (
SELECT Rno FROM ACADEMIC
WHERE SPI = (select top 1 SPI from (select top 2 spi from ACADEMIC order by SPI desc) as s order by SPI)
)


-- 8
SELECT * FROM STUDENT
WHERE DID IN (SELECT DID FROM DEPARTMENT WHERE DName IN ('Computer', 'Electrical'));


-- 9
SELECT * FROM STUDENT
WHERE DID IN (SELECT DID FROM DEPARTMENT WHERE DID IN (
SELECT DID FROM STUDENT WHERE Rno = 102
));


-- 10
SELECT Name FROM STUDENT
WHERE
Rno IN (SELECT Rno FROM ACADEMIC WHERE SPI > 9)
AND
DID IN (SELECT DID FROM DEPARTMENT WHERE DName = 'Electrical');





-- PART :::::::::::::: B

-- Create the COMPANY_MASTER table
CREATE TABLE COMPANY_MASTER (
    COM_ID INT PRIMARY KEY,
    COM_NAME VARCHAR(100) NOT NULL
);


-- Insert data into the COMPANY_MASTER table
INSERT INTO COMPANY_MASTER (COM_ID, COM_NAME) VALUES
(11, 'Samsung'),
(12, 'iBall'),
(13, 'Epsion'),
(14, 'Zebronics'),
(15, 'Asus'),
(16, 'Frontech');


-- Create the EMP_DETAILS table
CREATE TABLE EMP_DETAILS (
    EMP_IDNO INT PRIMARY KEY,
    EMP_FNAME VARCHAR(100) NOT NULL,
    EMP_LNAME VARCHAR(100) NOT NULL,
    EMP_DEPT INT NOT NULL
);


-- Insert data into the EMP_DETAILS table
INSERT INTO EMP_DETAILS (EMP_IDNO, EMP_FNAME, EMP_LNAME, EMP_DEPT) VALUES
(127323, 'Michale', 'Robbin', 57),
(526689, 'Carlos', 'Snares', 63),
(843795, 'Enric', 'Dosio', 57),
(328717, 'Jhon', 'Snares', 63),
(444527, 'Joseph', 'Dosni', 47),
(659831, 'Zanifer', 'Emily', 47),
(847674, 'Kuleswar', 'Sitaraman', 57),
(748681, 'Henrey', 'Gabriel', 47),
(555935, 'Alex', 'Manuel', 57),
(539569, 'George', 'Mardy', 27),
(733843, 'Mario', 'Saule', 63),
(631548, 'Alan', 'Snappy', 27),
(839139, 'Maria', 'Foster', 57);


-- Create the EMP_DEPARTMENT table
CREATE TABLE EMP_DEPARTMENT (
    DPT_CODE INT PRIMARY KEY,
    DPT_NAME VARCHAR(100) NOT NULL,
    DPT_ALLOTMENT DECIMAL(10,2) NOT NULL
);


-- Insert data into the EMP_DEPARTMENT table
INSERT INTO EMP_DEPARTMENT (DPT_CODE, DPT_NAME, DPT_ALLOTMENT) VALUES
(57, 'IT', 65000.00),
(63, 'Finance', 15000.00),
(47, 'HR', 240000.00),
(27, 'RD', 55000.00),
(89, 'QC', 75000.00);



CREATE TABLE ITEM_MASTER (
PRO_ID INT PRIMARY KEY,
PRO_NAME VARCHAR(255) NOT NULL,
PRO_PRICE INT NOT NULL,
PRO_COM INT NOT NULL
)

INSERT INTO ITEM_MASTER VALUES
(101, 'Mother Board', 3200, 15),
(102, 'Key Board', 450, 16),
(103, 'Zip drive', 250, 14),
(104, 'Speaker', 550, 16),
(105, 'Monitor', 5000, 11),
(106, 'DVD drive', 900, 12),
(107, 'CD drive', 800, 12),
(108, 'Printer', 2600, 12),
(109, 'Refill cartridge', 350, 13),
(110, 'Mouse', 250, 12);





-- 1
(SELECT PRO_COM, AVG(PRO_PRICE),
(SELECT COM_NAME FROM COMPANY_MASTER WHERE COM_ID = I.PRO_COM)
FROM ITEM_MASTER I GROUP BY PRO_COM);


-- 2
(SELECT PRO_COM, AVG(PRO_PRICE),
(SELECT COM_NAME FROM COMPANY_MASTER WHERE COM_ID = I.PRO_COM)
FROM ITEM_MASTER I GROUP BY PRO_COM HAVING AVG(PRO_PRICE) >= 350);


-- 3
SELECT PRO_NAME, MAX(PRO_PRICE) [Max],
(SELECT COM_NAME FROM COMPANY_MASTER WHERE COM_ID = I.PRO_COM) [Company Name]
FROM ITEM_MASTER I
WHERE PRO_PRICE = (SELECT TOP 1 PRO_PRICE FROM ITEM_MASTER WHERE PRO_COM = I.PRO_COM ORDER BY PRO_PRICE DESC)
GROUP BY PRO_COM, PRO_NAME;


-- 4
SELECT EMP_IDNO, EMP_FNAME, EMP_LNAME,
(SELECT DPT_NAME FROM EMP_DEPARTMENT WHERE DPT_CODE = EMP_DEPT) [Department]
FROM EMP_DETAILS
WHERE EMP_LNAME IN ('Gabriel', 'Dosio')


-- 5
SELECT EMP_IDNO, EMP_FNAME, EMP_LNAME,
(SELECT DPT_NAME FROM EMP_DEPARTMENT WHERE DPT_CODE = EMP_DEPT AND DPT_CODE IN (89, 63)) [Department]
FROM EMP_DETAILS
WHERE EMP_LNAME IN ('Gabriel', 'Dosio')














