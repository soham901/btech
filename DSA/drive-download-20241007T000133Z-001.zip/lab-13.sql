CREATE TABLE Person
(
    PersonID INT PRIMARY KEY,
    PersonName VARCHAR(100) NOT NULL,
    Salary DECIMAL(8,2) NOT NULL,
    JoiningDate DATETIME NOT NULL,
    City VARCHAR(100) NOT NULL,
    Age INT NULL,
    BirthDate DATETIME NOT NULL
);

CREATE TABLE PersonLog
(
    PLogID INT PRIMARY KEY IDENTITY(1,1),
    PersonID INT NULL,
    PersonName VARCHAR(250) NULL,
    Operation VARCHAR(50) NOT NULL,
    UpdateDate DATETIME NOT NULL
);

DROP TABLE PersonLog;



------------------------------ A ------------------------------

-- 1
CREATE TRIGGER Person_On_Ins_Dlt_Upd
ON PERSON
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
print 'Record is Affected'
END

DROP TRIGGER Person_On_Ins_Dlt_Upd



INSERT INTO Person VALUES (11, 'Abc', 20000, '2005-12-12', 'Abc', 12, '2005-12-12')
UPDATE Person SET PersonName = 'Xyz' WHERE PersonID = 11
DELETE Person WHERE PersonID = 11



-- 2
ALTER TRIGGER Person_Log_On_Upd_Dlt_Ins
ON PERSON
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
	DECLARE @PID INT;
	DECLARE @PersonName VARCHAR(250);
	DECLARE @Operation VARCHAR(50) = 'insert';

	SELECT @PID = PersonID, @PersonName = PersonName FROM inserted;

	IF EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
	BEGIN
	SET @Operation = 'update'
	SELECT @PID = PersonID, @PersonName = PersonName FROM inserted;
	END

	IF NOT EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
	BEGIN
	SET @Operation = 'delete'
	PRINT 'DELETE'
	SELECT @PID = PersonID, @PersonName = PersonName FROM deleted;
	END

	DECLARE @UpdateDate DATETIME = GETDATE();

	SELECT @PID, @PersonName, @Operation, @UpdateDate

	INSERT INTO PersonLog (PersonID, PersonName, Operation, UpdateDate)
	VALUES (@PID, @PersonName, @Operation, @UpdateDate);
END


DROP TRIGGER Person_Log_On_Upd_Dlt_Ins


SELECT * FROM PersonLog;

SELECT * FROM Person;

DELETE PersonLog;

DELETE Person;



INSERT INTO Person VALUES (47, 'Abc', 20000, '2005-12-12', 'Abc', 12, '2005-12-12')
UPDATE Person SET PersonName = 'Xyz' WHERE PersonID = 47
DELETE Person WHERE PersonID = 47



------------------------------ B ------------------------------



-- 1
CREATE TRIGGER Person_Log_On_Ins2
ON PERSON
INSTEAD OF INSERT
AS
BEGIN
	DECLARE @Operation VARCHAR(50) = 'insert';

	DECLARE @UpdateDate DATETIME = GETDATE();

	INSERT INTO PersonLog (PersonID, PersonName, Operation, UpdateDate)
	VALUES (NULL, NULL, @Operation, @UpdateDate);
END

DROP TRIGGER Person_Log_On_Ins2


CREATE TRIGGER Person_Log_On_Upd2
ON PERSON
INSTEAD OF UPDATE
AS
BEGIN
	DECLARE @Operation VARCHAR(50) = 'update';

	DECLARE @UpdateDate DATETIME = GETDATE();

	INSERT INTO PersonLog (PersonID, PersonName, Operation, UpdateDate)
	VALUES (NULL, NULL, @Operation, @UpdateDate);
END

DROP TRIGGER Person_Log_On_Upd2


CREATE TRIGGER Person_Log_On_Dlt2
ON PERSON
INSTEAD OF DELETE
AS
BEGIN
	DECLARE @Operation VARCHAR(50) = 'delete';

	DECLARE @UpdateDate DATETIME = GETDATE();

	INSERT INTO PersonLog (PersonID, PersonName, Operation, UpdateDate)
	VALUES (NULL, NULL, @Operation, @UpdateDate);
END

DROP TRIGGER Person_Log_On_Dlt2



SELECT * FROM PersonLog;

SELECT * FROM Person;

DELETE PersonLog;

DELETE Person;



INSERT INTO Person VALUES (45, 'Abc', 20000, '2005-12-12', 'Abc', 12, '2005-12-12')
UPDATE Person SET PersonName = 'Xyz' WHERE PersonID = 45
DELETE Person WHERE PersonID = 45




-- 2

ALTER TRIGGER Person_On_Ins_Uppercase
ON PERSON
AFTER INSERT
AS
BEGIN
	DECLARE @PID INT = (select PersonID from inserted)
	DECLARE @PNAME VARCHAR(100) = (select PersonName from inserted)
	UPDATE Person SET PersonName = UPPER(@PNAME) WHERE PersonID = @PID
END


DROP TRIGGER Person_On_Ins_Uppercase

select * from Person

INSERT INTO Person VALUES (11, 'Abc', 20000, '2005-12-12', 'Abc', 12, '2005-12-12')




------------------------------ C ------------------------------

-- 1
ALTER TRIGGER Person_On_Ins_Calc_Age
ON PERSON
AFTER INSERT
AS
BEGIN
	DECLARE @PID INT = (select PersonID from inserted)
	DECLARE @AGE INT = DATEDIFF(year, (select BirthDate from inserted), GETDATE());
	PRINT @AGE
	UPDATE Person SET Age = @AGE WHERE PersonID = @PID
END


DROP TRIGGER Person_On_Ins_Calc_Age

select * from Person

DELETE Person

INSERT INTO Person VALUES (10, 'Abc', 20000, '2005-12-12', 'Abc', NULL, '2005-12-12')


-- 2
ALTER TRIGGER PersonLog_After_Dlt
ON PersonLog
AFTER DELETE
AS
BEGIN
	PRINT 'Record deleted successfully from PersonLog'
END


DROP TRIGGER PersonLog_After_Dlt

select * from Person

DELETE Person

INSERT INTO Person VALUES (10, 'Abc', 20000, '2005-12-12', 'Abc', NULL, '2005-12-12')