CREATE TABLE Department (
    DepartmentID INT PRIMARY KEY,
    DepartmentName VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Designation (
    DesignationID INT PRIMARY KEY,
    DesignationName VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE PERSON (
    WorkerID INT PRIMARY KEY IDENTITY(1,1),
    FirstName VARCHAR(100) NOT NULL,
    LastName VARCHAR(100) NOT NULL,
    Salary DECIMAL(8,2) NOT NULL,
    JoiningDate DATETIME NOT NULL,
    DepartmentID INT NULL,
    DesignationID INT NULL,
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID),
    FOREIGN KEY (DesignationID) REFERENCES Designation(DesignationID)
);

INSERT INTO Department (DepartmentID, DepartmentName)
VALUES
(1, 'Admin'),
(2, 'IT'),
(3, 'HR'),
(4, 'Account');

INSERT INTO Designation (DesignationID, DesignationName)
VALUES
(11, 'Jobber'),
(12, 'Welder'),
(13, 'Clerk'),
(14, 'Manager'),
(15, 'CEO');

SET IDENTITY_INSERT PERSON ON;

INSERT INTO PERSON (WorkerID, FirstName, LastName, Salary, JoiningDate, DepartmentID, DesignationID)
VALUES 
(101, 'Rahul', 'Anshu', 56000, '1990-01-01', 1, 12),
(102, 'Hardik', 'Hinsu', 18000, '1990-09-25', 2, 11),
(103, 'Bhavin', 'Kamani', 25000, '1991-05-14', NULL, 11),
(104, 'Bhoomi', 'Patel', 39000, '2014-02-20', 1, 13),
(105, 'Rohit', 'Rajgor', 17000, '1990-07-23', 2, 15),
(106, 'Priya', 'Mehta', 25000, '1990-10-18', 2, NULL),
(107, 'Neha', 'Trivedi', 18000, '2014-02-20', 3, 15);

SET IDENTITY_INSERT PERSON OFF;

SELECT * FROM PERSON;


------------------------------------------------------- PART A -------------------------------------------------------

-- 1 : Create a Procedure on Department, Designation & Person Table for INSERT, UPDATE & DELETE Procedures.

-- 1. Department Insert
CREATE PROC PR_Department_Insert
@DepartmentID INT,
@DepartmentName VARCHAR(100)
AS
BEGIN
INSERT INTO Department (DepartmentID, DepartmentName) VALUES (@DepartmentID, @DepartmentName);
END

-- 2. Department Select All
CREATE PROC PR_Department_SelectAll
AS
BEGIN
SELECT * FROM Department
END

-- 3. Department Select By ID
CREATE PROC PR_Department_SelectByID
@DepartmentID INT
AS
BEGIN
SELECT * FROM Department WHERE DepartmentID = @DepartmentID
END


-- 4. Department Update By ID
CREATE PROC PR_Department_UpdateByID
@DepartmentID INT,
@DepartmentName VARCHAR(100)
AS
BEGIN
UPDATE Department SET DepartmentName = @DepartmentName WHERE DepartmentID = @DepartmentID;
END


-- 5. Department Delete By ID
CREATE PROC PR_Department_DeleteByID
@DepartmentID INT
AS
BEGIN
DELETE Department WHERE DepartmentID = @DepartmentID;
END



-- 1. Designation Insert
CREATE PROC PR_Designation_Insert
@DesignationID INT,
@DesignationName VARCHAR(100)
AS
BEGIN
INSERT INTO Designation (DesignationID, DesignationName) VALUES (@DesignationID, @DesignationName);
END

-- 2. Designation Select All
CREATE PROC PR_Designation_SelectAll
AS
BEGIN
SELECT * FROM Designation
END

-- 3. Designation Select By ID
CREATE PROC PR_Designation_SelectByID
@DesignationID INT
AS
BEGIN
SELECT * FROM Designation WHERE DesignationID = @DesignationID
END


-- 4. Designation Update By ID
CREATE PROC PR_Designation_UpdateByID
@DesignationID INT,
@DesignationName VARCHAR(100)
AS
BEGIN
UPDATE Designation SET DesignationName = @DesignationName WHERE DesignationID = @DesignationID;
END


-- 5. Designation Delete By ID
CREATE PROC PR_Designation_DeleteByID
@DesignationID INT
AS
BEGIN
DELETE Designation WHERE DesignationID = @DesignationID;
END





-- 1. Person Insert
CREATE PROC PR_Person_Insert
@WorkerID INT,
@FirstName VARCHAR(100),
@LastName VARCHAR(100),
@Salary DECIMAL(8,2),
@JoiningDate DATETIME,
@DepartmentID INT,
@DesignationID INT
AS
BEGIN
SET IDENTITY_INSERT PERSON ON;
INSERT INTO PERSON (WorkerID, FirstName, LastName, Salary, JoiningDate, DepartmentID, DesignationID) VALUES (@WorkerID, @FirstName, @LastName, @Salary, @JoiningDate, @DepartmentID, @DesignationID)
SET IDENTITY_INSERT PERSON OFF;
END


-- 2. PERSON Select All
CREATE PROC PR_PERSON_SelectAll
AS
BEGIN
SELECT * FROM PERSON
END

-- 3. PERSON Select By ID
CREATE PROC PR_PERSON_SelectByID
@WorkerID INT
AS
BEGIN
SELECT * FROM PERSON WHERE WorkerID = @WorkerID
END


-- 4. PERSON Update By ID
CREATE PROC PR_PERSON_UpdateByID
@WorkerID INT,
@FirstName VARCHAR(100),
@LastName VARCHAR(100),
@Salary DECIMAL(8,2),
@JoiningDate DATETIME,
@DepartmentID INT,
@DesignationID INT
AS
BEGIN
UPDATE PERSON
SET FirstName = @FirstName, LastName = @LastName, Salary = @Salary, JoiningDate = @JoiningDate, DepartmentID = @DepartmentID, DesignationID = @DesignationID
WHERE WorkerID = @WorkerID;
END


-- 5. PERSON Delete By ID
CREATE PROC PR_PERSON_DeleteByID
@WorkerID INT
AS
BEGIN
DELETE PERSON WHERE WorkerID = @WorkerID;
END


-- Department
EXEC PR_Department_Insert 5, 'New Department'
EXEC PR_Department_SelectAll
EXEC PR_Department_SelectByID 5
EXEC PR_Department_UpdateByID 5, 'Newest'
EXEC PR_Department_DeleteByID 5



-- Designation
EXEC PR_Designation_Insert 16, 'New Designation'
EXEC PR_Designation_SelectAll
EXEC PR_Designation_SelectByID 16
EXEC PR_Designation_UpdateByID 16, 'Newest'
EXEC PR_Designation_DeleteByID 16



-- Person
EXEC PR_Person_Insert 110, 'Xyz', 'Abc', 15000, '2020-03-15', 5, 16
EXEC PR_PERSON_SelectAll
EXEC PR_PERSON_SelectByID 110
EXEC PR_PERSON_UpdateByID 110, 'New Xyz', 'New Abc', 25000, '2020-03-20', 1, 12
EXEC PR_PERSON_DeleteByID 110



-- 3
CREATE PROC PR_DISPLAY_Merged_Data
AS
BEGIN
SELECT * FROM PERSON p INNER JOIN Department dt
ON p.DepartmentID = dt.DepartmentID
INNER JOIN Designation ds
ON p.DesignationID = ds.DesignationID
END

EXEC PR_DISPLAY_Merged_Data


-- 4
CREATE PROC PR_Person_Select_Top
@TOP INT
AS
BEGIN
SELECT TOP (@TOP) * FROM PERSON
END

EXEC PR_Person_Select_Top 3




------------------------------------------------------- PART B -------------------------------------------------------

-- 1
CREATE PROC PR_PERSON_BY_DEPT
@DEPT_NAME VARCHAR(100)
AS
BEGIN
	SELECT * FROM PERSON p INNER JOIN Department d
	ON p.DepartmentID = d.DepartmentID
	WHERE d.DepartmentName = @DEPT_NAME
END


EXEC PR_PERSON_BY_DEPT 'IT'


-- 2
CREATE PROC PR_PERSON_BY_DEPT_AND_DESI
@DEPT_NAME VARCHAR(100),
@DESI_NAME VARCHAR(100)
AS
BEGIN
SELECT * FROM PERSON p INNER JOIN Department dt
ON p.DepartmentID = dt.DepartmentID
INNER JOIN Designation ds
ON p.DesignationID = ds.DesignationID
WHERE dt.DepartmentName = @DEPT_NAME AND ds.DesignationName = @DESI_NAME
END


EXEC PR_PERSON_BY_DEPT_AND_DESI 'IT', 'CEO'


-- 3
CREATE PROC PR_PERSON_SELECT_BY_FIRSTNAME
@FIRSTNAME VARCHAR(100)
AS
BEGIN
SELECT * FROM PERSON p INNER JOIN Department dt
ON p.DepartmentID = dt.DepartmentID
INNER JOIN Designation ds
ON p.DesignationID = ds.DesignationID
WHERE p.FirstName = @FIRSTNAME
END


EXEC PR_PERSON_SELECT_BY_FIRSTNAME 'Rohit'



-- 4
CREATE PROC PR_DEPARTMENT_SALARY_AGG
AS
BEGIN
SELECT d.DepartmentName, MAX(p.Salary) [Max], MIN(p.Salary) [Min], SUM(p.Salary) [Sum] FROM PERSON p
INNER JOIN Department d
ON p.DepartmentID = d.DepartmentID
GROUP BY d.DepartmentName
END


EXEC PR_DEPARTMENT_SALARY_AGG



-- 5
CREATE PROC PR_DESIGNATION_SALARY_AGG
AS
BEGIN
SELECT d.DesignationName, AVG(p.Salary) [Avg], SUM(p.Salary) [Sum] FROM PERSON p
INNER JOIN Designation d
ON p.DesignationID = d.DesignationID
GROUP BY d.DesignationName
END


EXEC PR_DEPARTMENT_SALARY_AGG







