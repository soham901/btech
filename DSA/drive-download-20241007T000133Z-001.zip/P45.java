import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * P45 : Write a program to convert infix notation to postfix notation using
 * stack.
 */

public class P45 {
    static interface Stack {
        void push(char val);

        char pop();

        int peep(int idx);

        void display();
    }

    static Map<Character, Integer> gValues = new HashMap<>();
    static Map<Character, Integer> fValues = new HashMap<>();

    static {
        fValues.put('+', 1);
        fValues.put('-', 1);
        fValues.put('*', 3);
        fValues.put('/', 3);
        fValues.put('^', 6);
        fValues.put('(', 9);
        fValues.put(')', 0);

        gValues.put('+', 2);
        gValues.put('-', 2);
        gValues.put('*', 4);
        gValues.put('/', 4);
        gValues.put('^', 5);
        gValues.put('(', 0);
    }

    static int G(char c) {
        try {
            return gValues.get(c);
        } catch (Exception e) {
            return 8; // variable
        }
    }

    static int F(char c) {
        try {
            return fValues.get(c);
        } catch (Exception e) {
            return 7; // variable
        }
    }

    static int R(char c) {
        if (Pattern.matches("[a-z]", Character.toString(c)))
            return 1;
        return -1;
    }

    static class Arr implements Stack {
        static char[] arr = new char[10000];
        int top = -1;

        public char getTopElement() {
            if (top == -1)
                throw new Error("Stack is underflow");
            return arr[top];
        }

        @Override
        public void push(char val) {
            if (top == 10000)
                throw new Error("Stack is overflow");
            top += 1;
            arr[top] = val;
        }

        @Override
        public char pop() {
            if (top == -1)
                throw new Error("Stack is underflow");
            char val = arr[top];
            top -= 1;
            return val;
        }

        @Override
        public int peep(int idx) {
            if (top == -1)
                throw new Error("Stack is underflow");
            return arr[top - idx];
        }

        @Override
        public void display() {
            for (int i = 0; i < top + 1; i++) {
                System.out.print(arr[i] + " ");
            }
            System.out.println();
        }
    }

    static String infixToPostfix(String input) {
        int n = input.length(), rank = 0;
        Arr stack = new Arr();
        String polish = "";
        char next = ' ', temp = ' ';

        stack.push('(');

        for (int i = 0; i < n; i++) {
            next = input.charAt(i);
            
            while(G(stack.getTopElement()) > F(next)) {
                temp = stack.pop();
                polish += temp;
                rank += R(temp);

                if(rank < 1) return "";
            }

            if(G(stack.getTopElement()) != F(next)) stack.push(next);

            else stack.pop();
        }

        return polish;
    }

    public static void main(String[] args) {
        test();

        // Scanner sc = new Scanner(System.in);
        // String input = "abcba";//sc.next();

        // System.out.println(input + " is" + (isValidString(input) ? "" : " not") + "
        // Valid String");

        // sc.close();
    }

    static void test() {
        // test 1
        assert infixToPostfix("a+b)").equals("ab+") : "Failed t1";

        // // test 2
        assert infixToPostfix("a+b+c)").equals("ab+c+") : "Failed t2";

        // // test 3
        assert infixToPostfix("a+(b+c))").equals("abc++") : "Failed t3";

        // // test 4
        assert infixToPostfix("(a+b^c^d)*(e+f/d))").equals("abcd^^+efd/+*") : "Failed t4";

        System.out.println("All test cases passed");
    }
}
